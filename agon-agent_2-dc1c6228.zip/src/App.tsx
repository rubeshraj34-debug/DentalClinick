import { useEffect, useMemo, useState } from 'react'
import {
  ArrowRight,
  CalendarCheck2,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Menu,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  Stethoscope,
  X,
} from 'lucide-react'

const logoSrc = '/images/clinic-logo.png'
const phoneNumber = '062014 78033'
const phoneHref = 'tel:06201478033'
const whatsappHref = 'https://wa.me/916201478033?text=Hello%20Doctor,%20I%20would%20like%20to%20book%20a%20dental%20appointment.'
const address =
  'Tara Kunj, 1F/111, beside Lotus Apartment, New Patliputra Colony, Patna, Bihar 800013'

const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'services', label: 'Services' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'about', label: 'About Us' },
  { id: 'testimonials', label: 'Testimonials' },
  { id: 'contact', label: 'Contact Us' },
]

const services = [
  {
    title: 'Teeth Cleaning',
    description: 'Regular scaling and polishing for fresh breath, stain removal, and healthier gums.',
  },
  {
    title: 'Root Canal Treatment',
    description: 'Comfort-focused treatment to save infected teeth and reduce dental pain effectively.',
  },
  {
    title: 'Tooth Extraction',
    description: 'Safe and careful tooth removal with proper guidance for quick healing.',
  },
  {
    title: 'Dental Implants',
    description: 'Long-term replacement option for missing teeth with a natural-looking result.',
  },
  {
    title: 'Teeth Whitening',
    description: 'Brighten your smile with gentle cosmetic treatment tailored for visible results.',
  },
  {
    title: 'Gum Treatment',
    description: 'Treatment for bleeding, swelling, sensitivity, and other gum-related problems.',
  },
]

const galleryImages = [
  { title: 'Clinic Hero View', src: '/images/dental-hero-updated.jpg' },
  { title: 'Clinic Interior', src: '/images/gallery-clinic-interior.png' },
  { title: 'Equipment Setup', src: '/images/gallery-equipment.png' },
  { title: 'Healthy Smile', src: '/images/gallery-smile.png' },
  {
    title: 'Dental Chair',
    src: 'https://images.unsplash.com/photo-1588776814546-daab30f310ce?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Treatment Area',
    src: 'https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=900&q=80',
  },
]

const testimonials = [
  {
    name: 'Ritika S.',
    text: 'The clinic is very clean and treatment was explained clearly. Booking was easy and my experience was comfortable.',
  },
  {
    name: 'Amit K.',
    text: 'Professional doctor, polite staff, and very smooth teeth cleaning. Strongly recommended in Patliputra.',
  },
  {
    name: 'Neha P.',
    text: 'Quick appointment support on WhatsApp and very good treatment quality. Felt safe and cared for.',
  },
]

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [appointmentSubmitted, setAppointmentSubmitted] = useState(false)
  const [contactSubmitted, setContactSubmitted] = useState(false)
  const [appointmentData, setAppointmentData] = useState({
    name: '',
    phone: '',
    service: '',
  })
  const [contactData, setContactData] = useState({
    name: '',
    phone: '',
    message: '',
  })

  const mapEmbed = useMemo(
    () => `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`,
    [],
  )

  useEffect(() => {
    const ids = navItems.map((item) => item.id)
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]
        if (visible) setActiveSection(visible.target.id)
      },
      { threshold: [0.35, 0.6], rootMargin: '-15% 0px -50% 0px' },
    )

    ids.forEach((id) => {
      const element = document.getElementById(id)
      if (element) observer.observe(element)
    })

    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    document.title = 'YOUR DENTIST | Modern Dentist Website in Patna'

    const setMeta = (name: string, content: string, property = false) => {
      const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`
      let meta = document.querySelector(selector) as HTMLMetaElement | null
      if (!meta) {
        meta = document.createElement('meta')
        if (property) meta.setAttribute('property', name)
        else meta.setAttribute('name', name)
        document.head.appendChild(meta)
      }
      meta.setAttribute('content', content)
    }

    setMeta(
      'description',
      'Modern dental clinic website for YOUR DENTIST in Patna with services, gallery, testimonials, and appointment contact options.',
    )
    setMeta(
      'keywords',
      'Dentist in Patna, Dental clinic in Patna, Best dentist in Patliputra, Teeth cleaning Patna, RCT in Patna',
    )

    const existingSchema = document.getElementById('local-business-schema')
    if (existingSchema) existingSchema.remove()

    const schema = document.createElement('script')
    schema.type = 'application/ld+json'
    schema.id = 'local-business-schema'
    schema.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Dentist',
      name: 'YOUR DENTIST',
      image: '/images/dental-hero-updated.jpg',
      address: {
        '@type': 'PostalAddress',
        streetAddress: 'Tara Kunj, 1F/111, beside Lotus Apartment, New Patliputra Colony',
        addressLocality: 'Patna',
        addressRegion: 'Bihar',
        postalCode: '800013',
        addressCountry: 'IN',
      },
      telephone: phoneNumber,
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: '5.0',
        reviewCount: '160',
      },
      openingHours: ['Mo-Sa 09:00-20:00', 'Su 10:00-14:00'],
      url: window.location.href,
    })
    document.head.appendChild(schema)

    return () => {
      const cleanupSchema = document.getElementById('local-business-schema')
      if (cleanupSchema) cleanupSchema.remove()
    }
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' })
      setMobileOpen(false)
    }
  }

  const handleAppointmentSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setAppointmentSubmitted(true)
    setAppointmentData({ name: '', phone: '', service: '' })
  }

  const handleContactSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setContactSubmitted(true)
    setContactData({ name: '', phone: '', message: '' })
  }

  return (
    <div className="min-h-screen bg-[#edf7ff] text-slate-800">
      <header className="sticky top-0 z-50 border-b border-white/40 bg-white/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <button onClick={() => scrollToSection('home')} className="flex items-center gap-3 text-left">
            <div className="overflow-hidden rounded-2xl border border-sky-100 bg-white shadow-sm">
              <img src={logoSrc} alt="YOUR DENTIST logo" className="h-11 w-11 object-cover" />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">YOUR DENTIST</p>
              <p className="text-xs text-slate-500">Trusted dental care in Patna</p>
            </div>
          </button>

          <nav className="hidden items-center gap-2 rounded-full border border-white/60 bg-white/70 px-3 py-2 lg:flex">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                  activeSection === item.id
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-sky-50 hover:text-sky-700'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <a href={phoneHref} className="rounded-full border border-sky-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm">
              {phoneNumber}
            </a>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-sky-200"
            >
              <MessageCircle className="h-4 w-4" />
              WhatsApp
            </a>
          </div>

          <button
            className="rounded-full border border-sky-200 bg-white p-2 text-sky-700 lg:hidden"
            onClick={() => setMobileOpen((value) => !value)}
            aria-label="Toggle navigation"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {mobileOpen && (
          <div className="border-t border-sky-100 bg-white/95 px-4 py-4 lg:hidden">
            <div className="flex flex-col gap-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="rounded-2xl px-4 py-3 text-left text-sm font-medium text-slate-700 hover:bg-sky-50"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <main>
        <section id="home" className="relative overflow-hidden">
          <div className="absolute inset-0">
            <video
              className="h-full w-full object-cover"
              autoPlay
              muted
              loop
              playsInline
            >
              <source src="/videos/hero-background.mp4" type="video/mp4" />
            </video>
            <div className="absolute inset-0 bg-[linear-gradient(110deg,rgba(3,7,18,0.72),rgba(14,165,233,0.22),rgba(255,255,255,0.08))]" />
            <div className="sun-glow absolute right-[12%] top-[12%] h-44 w-44 rounded-full bg-white/50 blur-3xl" />
            <div className="cloud cloud-one absolute left-[-10%] top-[16%] h-20 w-44 rounded-full bg-white/35 blur-xl" />
            <div className="cloud cloud-two absolute left-[20%] top-[24%] h-16 w-36 rounded-full bg-white/30 blur-xl" />
            <div className="cloud cloud-three absolute right-[18%] top-[18%] h-24 w-52 rounded-full bg-white/30 blur-xl" />
          </div>

          <div className="relative mx-auto flex min-h-[88vh] max-w-7xl items-center px-4 py-20 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-black/20 px-4 py-2 text-sm font-medium text-white/95 backdrop-blur-sm">
                <Star className="h-4 w-4 fill-current text-yellow-300" />
                5.0 ★ Rated by 160+ Patients in Patna
              </div>
              <h1 className="mt-6 text-4xl font-bold leading-tight text-white sm:text-5xl lg:text-6xl">
                Trusted Dental Care in Patna
              </h1>
              <p className="mt-5 max-w-2xl text-base leading-8 text-sky-50 sm:text-lg">
                Affordable and professional dental treatment with experienced care, modern equipment, and a patient-friendly approach for healthy and confident smiles.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <button
                  onClick={() => scrollToSection('contact')}
                  className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-sky-700 shadow-lg"
                >
                  <CalendarCheck2 className="h-4 w-4" />
                  Book Appointment
                </button>
                <a
                  href={phoneHref}
                  className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-black/20 px-6 py-3 text-sm font-semibold text-white backdrop-blur-sm"
                >
                  <Phone className="h-4 w-4" />
                  Call Now
                </a>
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-emerald-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/30"
                >
                  <MessageCircle className="h-4 w-4" />
                  WhatsApp
                </a>
              </div>

              <div className="mt-10 grid gap-4 md:grid-cols-3">
                {[
                  'Dental clinic in Patliputra Colony',
                  'Fast call and WhatsApp booking',
                  'Modern look with simple patient journey',
                ].map((item) => (
                  <div key={item} className="rounded-2xl border border-white/20 bg-black/20 px-4 py-4 text-sm text-white/90 backdrop-blur-sm">
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="gallery" className="px-4 pb-8 pt-16 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="mb-8 max-w-2xl">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700">Gallery</p>
              <h2 className="mt-2 text-3xl font-bold text-slate-900 sm:text-4xl">More images and a fuller modern visual design</h2>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {galleryImages.map((image, index) => (
                <button
                  key={image.title}
                  onClick={() => setSelectedImage(image.src)}
                  className={`group overflow-hidden rounded-[1.8rem] border border-white/70 bg-white shadow-sm ${
                    index === 0 ? 'sm:col-span-2' : ''
                  }`}
                >
                  <div className="overflow-hidden">
                    <img
                      src={image.src}
                      alt={image.title}
                      className={`w-full object-cover transition duration-500 group-hover:scale-105 ${
                        index === 0 ? 'h-72' : 'h-64'
                      }`}
                    />
                  </div>
                  <div className="flex items-center justify-between p-5 text-left">
                    <div>
                      <p className="font-semibold text-slate-900">{image.title}</p>
                      <p className="mt-1 text-sm text-slate-500">Tap to enlarge</p>
                    </div>
                    <div className="rounded-full bg-sky-50 p-3 text-sky-700">
                      <ChevronRight className="h-4 w-4" />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1.05fr_0.95fr]">
            <div className="rounded-[2rem] border border-white/60 bg-white p-6 shadow-sm sm:p-8">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700">About Us</p>
              <h2 className="mt-3 text-3xl font-bold text-slate-900 sm:text-4xl">Modern presentation, simple content, higher trust</h2>
              <div className="mt-5 space-y-4 text-slate-600">
                <p>
                  YOUR DENTIST is designed here as a more modern and polished clinic website while keeping navigation simple and useful for local patients.
                </p>
                <p>
                  The clinic highlights professional dental treatment, hygienic care, patient comfort, and fast communication through calls and WhatsApp.
                </p>
                <p>
                  This updated version gives the website a stronger visual identity with image-led design, soft gradients, glass-like cards, and premium spacing.
                </p>
              </div>
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {[
                  'Professional dental care',
                  'Sterilized and hygienic clinic setup',
                  'Family-friendly atmosphere',
                  'Easy contact and appointment support',
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3 rounded-2xl bg-sky-50 p-4 text-sm text-slate-700">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-sky-600" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid gap-5">
              <div className="overflow-hidden rounded-[2rem] border border-white/60 bg-white shadow-sm">
                <img src="/images/gallery-clinic-interior.png" alt="Clinic interior" className="h-64 w-full object-cover" />
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="rounded-[2rem] border border-white/60 bg-[linear-gradient(180deg,#f0f9ff,#ffffff)] p-6 shadow-sm">
                  <ShieldCheck className="h-10 w-10 text-sky-600" />
                  <h3 className="mt-4 text-lg font-semibold text-slate-900">Hygiene First</h3>
                  <p className="mt-2 text-sm leading-7 text-slate-600">Clean environment, sterilized instruments, and careful treatment process.</p>
                </div>
                <div className="rounded-[2rem] border border-white/60 bg-[linear-gradient(180deg,#f0f9ff,#ffffff)] p-6 shadow-sm">
                  <Clock3 className="h-10 w-10 text-sky-600" />
                  <h3 className="mt-4 text-lg font-semibold text-slate-900">Quick Response</h3>
                  <p className="mt-2 text-sm leading-7 text-slate-600">Simple inquiry path that helps patients call or message quickly.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="px-4 pb-8 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_30px_80px_rgba(14,165,233,0.10)] backdrop-blur-xl sm:p-8">
            <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700">Services</p>
                <h2 className="mt-2 text-3xl font-bold text-slate-900 sm:text-4xl">Simple service pages in a more premium style</h2>
              </div>
              <button
                onClick={() => scrollToSection('contact')}
                className="inline-flex items-center gap-2 text-sm font-semibold text-sky-700"
              >
                Request Treatment
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {services.map((service, index) => (
                <article
                  key={service.title}
                  className="group rounded-[1.75rem] border border-sky-100 bg-[linear-gradient(180deg,#ffffff,#f0f9ff)] p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl"
                >
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
                    <span className="text-lg font-bold">0{index + 1}</span>
                  </div>
                  <h3 className="mt-5 text-xl font-semibold text-slate-900">{service.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
                  <button
                    onClick={() => scrollToSection('contact')}
                    className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-sky-700"
                  >
                    Learn More
                    <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                  </button>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="testimonials" className="px-4 py-8 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl rounded-[2rem] border border-white/70 bg-white p-6 shadow-sm sm:p-8">
            <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700">Testimonials</p>
                <h2 className="mt-2 text-3xl font-bold text-slate-900 sm:text-4xl">Small-space review cards with clean modern layout</h2>
              </div>
              <div className="rounded-full bg-sky-50 px-5 py-3 text-sm font-semibold text-sky-700">
                5.0 ★ Rated by 160+ Patients
              </div>
            </div>

            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {testimonials.map((item) => (
                <article key={item.name} className="rounded-[1.75rem] border border-sky-100 bg-[linear-gradient(180deg,#ffffff,#f8fcff)] p-6">
                  <div className="flex items-center gap-1 text-amber-500">
                    {Array.from({ length: 5 }).map((_, index) => (
                      <Star key={index} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="mt-4 text-sm leading-7 text-slate-600">“{item.text}”</p>
                  <p className="mt-5 font-semibold text-slate-900">{item.name}</p>
                  <p className="text-sm text-slate-500">Google Review</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-[0.95fr_1.05fr]">
            <div className="rounded-[2rem] border border-white/70 bg-white p-6 shadow-sm sm:p-8">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700">Contact Us</p>
              <h2 className="mt-3 text-3xl font-bold text-slate-900 sm:text-4xl">Book your appointment today</h2>
              <div className="mt-6 space-y-5 text-slate-600">
                <div>
                  <p className="text-sm font-semibold text-slate-500">Address</p>
                  <p className="mt-1 leading-7 text-slate-700">{address}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-500">Phone</p>
                  <a href={phoneHref} className="mt-1 inline-flex items-center gap-2 text-lg font-semibold text-sky-700">
                    <Phone className="h-4 w-4" />
                    {phoneNumber}
                  </a>
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-500">Clinic Timings</p>
                  <p className="mt-1 text-slate-700">Mon – Sat: 9:00 AM – 8:00 PM</p>
                  <p className="text-slate-700">Sun: 10:00 AM – 2:00 PM</p>
                </div>
              </div>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noreferrer"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/30"
              >
                <MessageCircle className="h-4 w-4" />
                Chat on WhatsApp
              </a>
              <div className="mt-8 overflow-hidden rounded-[1.75rem] border border-sky-100">
                <iframe
                  title="YOUR DENTIST Map"
                  src={mapEmbed}
                  className="h-72 w-full"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            <div className="grid gap-6">
              <form onSubmit={handleAppointmentSubmit} className="rounded-[2rem] border border-white/70 bg-white p-6 shadow-sm sm:p-8">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
                    <CalendarCheck2 className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900">Appointment Form</h3>
                    <p className="text-sm text-slate-500">Clean and short booking form</p>
                  </div>
                </div>

                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <input
                    required
                    type="text"
                    placeholder="Full Name"
                    value={appointmentData.name}
                    onChange={(event) => setAppointmentData({ ...appointmentData, name: event.target.value })}
                    className="rounded-2xl border border-sky-100 bg-sky-50/30 px-4 py-3 outline-none transition focus:border-sky-400"
                  />
                  <input
                    required
                    type="tel"
                    placeholder="Phone Number"
                    value={appointmentData.phone}
                    onChange={(event) => setAppointmentData({ ...appointmentData, phone: event.target.value })}
                    className="rounded-2xl border border-sky-100 bg-sky-50/30 px-4 py-3 outline-none transition focus:border-sky-400"
                  />
                  <select
                    required
                    value={appointmentData.service}
                    onChange={(event) => setAppointmentData({ ...appointmentData, service: event.target.value })}
                    className="sm:col-span-2 rounded-2xl border border-sky-100 bg-sky-50/30 px-4 py-3 outline-none transition focus:border-sky-400"
                  >
                    <option value="">Select Service</option>
                    {services.map((service) => (
                      <option key={service.title} value={service.title}>
                        {service.title}
                      </option>
                    ))}
                  </select>
                </div>

                <button className="mt-6 rounded-full bg-sky-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-sky-200">
                  Submit Booking
                </button>
                {appointmentSubmitted && (
                  <p className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                    Appointment request submitted in demo mode.
                  </p>
                )}
              </form>

              <form onSubmit={handleContactSubmit} className="rounded-[2rem] border border-white/70 bg-white p-6 shadow-sm sm:p-8">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900">Quick Contact</h3>
                    <p className="text-sm text-slate-500">Short inquiry form</p>
                  </div>
                </div>
                <div className="mt-6 grid gap-4">
                  <input
                    required
                    type="text"
                    placeholder="Your Name"
                    value={contactData.name}
                    onChange={(event) => setContactData({ ...contactData, name: event.target.value })}
                    className="rounded-2xl border border-sky-100 bg-sky-50/30 px-4 py-3 outline-none transition focus:border-sky-400"
                  />
                  <input
                    required
                    type="tel"
                    placeholder="Phone Number"
                    value={contactData.phone}
                    onChange={(event) => setContactData({ ...contactData, phone: event.target.value })}
                    className="rounded-2xl border border-sky-100 bg-sky-50/30 px-4 py-3 outline-none transition focus:border-sky-400"
                  />
                  <textarea
                    rows={4}
                    placeholder="Message"
                    value={contactData.message}
                    onChange={(event) => setContactData({ ...contactData, message: event.target.value })}
                    className="rounded-2xl border border-sky-100 bg-sky-50/30 px-4 py-3 outline-none transition focus:border-sky-400"
                  />
                </div>
                <button className="mt-6 rounded-full bg-slate-900 px-6 py-3 text-sm font-semibold text-white">
                  Send Inquiry
                </button>
                {contactSubmitted && (
                  <p className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                    Contact inquiry submitted in demo mode.
                  </p>
                )}
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/50 bg-white/70 py-6 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 text-sm text-slate-600 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <p>© YOUR DENTIST, Patna</p>
          <p>Home • Services • Gallery • About Us • Testimonials • Contact Us</p>
        </div>
      </footer>

      <a
        href={whatsappHref}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-full bg-[#25D366] px-5 py-3 text-sm font-semibold text-white shadow-2xl"
      >
        <MessageCircle className="h-4 w-4" />
        WhatsApp
      </a>

      {selectedImage && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/80 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-5xl">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute right-3 top-3 rounded-full bg-white p-2 text-slate-900"
              aria-label="Close image"
            >
              <X className="h-5 w-5" />
            </button>
            <img src={selectedImage} alt="Gallery preview" className="max-h-[86vh] rounded-[2rem] object-contain shadow-2xl" />
          </div>
        </div>
      )}
    </div>
  )
}

export default App
